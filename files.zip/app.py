import os, json, random
import pandas as pd
import streamlit as st

st.set_page_config(page_title="ConceptPilot", page_icon="⚡", layout="wide")
st.markdown("<style>.block-container{padding-top:1.4rem}"
            ".card{border:1px solid rgba(127,127,127,.35);border-radius:10px;padding:12px 16px;"
            "background:rgba(127,127,127,.08);margin:8px 0}</style>", unsafe_allow_html=True)

# ---------- 1. CONCEPT GRAPH (Class 10 Physics: Electricity) ----------
CONCEPTS = {  # id: (label, prerequisites)
    "charge": ("Electric charge", []),
    "current": ("Electric current", ["charge"]),
    "pd": ("Potential difference", ["charge"]),
    "ohm": ("Ohm's law", ["current", "pd"]),
    "resistance": ("Resistance", ["ohm"]),
    "series": ("Series circuits", ["resistance"]),
    "parallel": ("Parallel circuits", ["resistance"]),
    "power": ("Electric power", ["ohm"]),
}
# Well-documented student misconceptions about circuits (physics education research)
MISC = {
    "M1": "Current is 'used up' as it passes through a bulb or resistor",
    "M2": "Battery is a constant-current source (current does not depend on the circuit)",
    "M3": "Confuses current, voltage and/or energy",
    "M4": "Battery makes or stores charge that runs out",
    "M5": "Adding resistors in parallel increases the total resistance",
    "M6": "Resistance depends on the voltage or current applied",
}
ACTIONS = {
    "M1": "Reteach: put ammeters before and after a bulb (PhET circuit simulator). Current is the same.",
    "M2": "Reteach: show that changing the circuit changes the current drawn from the same battery.",
    "M3": "Reteach: water-pipe analogy. Voltage pushes, current flows, energy is transferred.",
    "M4": "Reteach: the battery supplies potential difference. The charge is already in the wires.",
    "M5": "Reteach: parallel adds more paths, so total resistance falls. Work 1/R = 1/R1 + 1/R2.",
    "M6": "Reteach: plot V against I for a resistor. The slope (R) stays constant.",
}

def Q(i, c, d, q, o, a, t):
    return dict(id=i, c=c, d=d, q=q, opts=o, ans=a, tags=t)

# Verified question bank; wrong options are tagged with the misconception they reveal.
BANK = [
    Q("q1", "charge", 1, "What is the SI unit of electric charge?", ["Coulomb", "Ampere", "Volt", "Ohm"], 0, [None, "M3", "M3", None]),
    Q("q2", "current", 1, "In a series circuit, ammeter A1 before a bulb reads 2 A. Ammeter A2 after the bulb reads:", ["2 A", "Less than 2 A, the bulb uses up some current", "0 A", "More than 2 A"], 0, [None, "M1", None, None]),
    Q("q3", "pd", 1, "What does a battery mainly provide to a circuit?", ["A potential difference that pushes charge around", "A fixed current, whatever the circuit", "A store of charge that gets used up", "Electrons that it creates"], 0, [None, "M2", "M4", "M4"]),
    Q("q4", "ohm", 2, "A resistor has 6 V across it and carries 2 A. At the same temperature the voltage is raised to 12 V. The current becomes:", ["4 A", "2 A", "6 A", "1 A"], 0, [None, "M2", None, None]),
    Q("q5", "resistance", 2, "A wire has resistance 10 Ω at 2 V. At 4 V (same temperature) its resistance is:", ["20 Ω", "10 Ω", "5 Ω", "40 Ω"], 1, ["M6", None, "M6", None]),
    Q("q6", "series", 2, "Two identical bulbs are in series with a battery. Compared with the first bulb, the current in the second is:", ["The same", "Smaller, the first bulb uses some", "Twice as large", "Zero"], 0, [None, "M1", None, None]),
    Q("q7", "parallel", 3, "Two 6 Ω resistors are connected in parallel. Their combined resistance is:", ["12 Ω", "6 Ω", "3 Ω", "9 Ω"], 2, ["M5", None, None, "M5"]),
    Q("q8", "power", 3, "A 6 V battery drives 0.5 A through a bulb. The power of the bulb is:", ["3 W", "12 W", "0.083 W", "6.5 W"], 0, [None, "M3", None, "M3"]),
    Q("q9", "pd", 2, "A voltmeter measures the potential difference across a bulb. It must be connected:", ["In parallel with the bulb", "In series with the bulb", "Only across the battery", "Anywhere, it makes no difference"], 0, [None, "M3", None, None]),
    Q("q10", "series", 3, "Three 2 Ω resistors in series are connected to a 6 V battery. The current from the battery is:", ["1 A", "3 A", "0.33 A", "12 A"], 0, [None, None, None, "M3"]),
    Q("q11", "parallel", 2, "A third identical bulb is added in parallel to two identical bulbs on the same battery. The current drawn from the battery:", ["Increases", "Decreases", "Stays the same", "Becomes zero"], 0, [None, "M5", "M2", None]),
    Q("q12", "charge", 2, "A current of 3 A flows for 4 s. The charge that passes is:", ["12 C", "0.75 C", "7 C", "1.33 C"], 0, [None, None, None, None]),
]
DIAG = BANK[:8]  # diagnostic test: one question per concept
INTERVALS = [1, 3, 7, 14, 30]  # spaced-repetition ladder (days)

# ---------- state ----------
s = st.session_state
if "m" not in s:
    s.m = {c: 0.3 for c in CONCEPTS}; s.phase = "diag"; s.i = 0; s.q = None; s.res = None
    s.attempt = 0; s.asked = set(); s.log = []; s.stats = {}; s.misc = {k: 0 for k in MISC}
    s.day = 0; s.due = {c: 0 for c in CONCEPTS}; s.streak = {c: 0 for c in CONCEPTS}
    s.focus = {}; s.dx = None; s.ai_err = None

# ---------- 3. LEARNER MODEL (Bayesian Knowledge Tracing) ----------
def bkt(p, correct, guess=0.25, slip=0.1, learn=0.12):
    if correct:
        post = p * (1 - slip) / (p * (1 - slip) + (1 - p) * guess)
    else:
        post = p * slip / (p * slip + (1 - p) * (1 - guess))
    return post + (1 - post) * learn

def emp_diff(q):  # item difficulty: AI/labelled prior blended with real answers
    c, t = s.stats.get(q["id"], (0, 0))
    return round((q["d"] / 3 * 3 + (t - c)) / (3 + t), 2)

# ---------- AI ----------
def ai_json(prompt):
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        try: key = st.secrets["GEMINI_API_KEY"]
        except Exception: s.ai_err = "No GEMINI_API_KEY set"; return None
    try:
        from google import genai
        r = genai.Client(api_key=key).models.generate_content(
            model=os.environ.get("GEMINI_MODEL", "gemini-2.5-flash"), contents=prompt,
            config={"response_mime_type": "application/json"})
        s.ai_err = None
        return json.loads(r.text)
    except Exception as e:
        s.ai_err = str(e)[:160]; return None

# ---------- 4. TARGETED QUESTIONS + DIFFICULTY CALIBRATION ----------
def pick_concept():
    due = [c for c in CONCEPTS if s.due[c] <= s.day]          # 6. spaced repetition: due first
    c0 = min(due or list(CONCEPTS), key=lambda x: s.m[x])
    c = c0
    for p in CONCEPTS[c0][1]:                                  # 2. weak prerequisite first
        if s.m[p] < s.m[c0] - 0.1: c = p
    return c

def gen_q(c):
    d = 1 if s.m[c] < 0.4 else 2 if s.m[c] < 0.7 else 3
    foc = s.focus.get(c)
    r = ai_json(f"""You write CBSE Class 10 Physics (chapter: Electricity) MCQs.
Concept: {CONCEPTS[c][0]}. Difficulty {d} (1 easy, 3 hard).
{('Design the question so a student holding this misconception picks a wrong option: ' + MISC[foc]) if foc else ''}
Exactly 4 options, exactly one correct, physically and numerically correct.
Tag each option with the misconception id it would reveal from {json.dumps(MISC)}, or null.
Return JSON: {{"q": str, "opts": [4 str], "ans": int 0-3, "tags": [4 x id or null], "why": str}}""")
    try:
        if r and len(r["opts"]) == 4 and r["ans"] in range(4):
            return dict(id=f"ai{len(s.log)}", c=c, d=d, q=r["q"], opts=r["opts"], ans=r["ans"],
                        tags=[t if t in MISC else None for t in r.get("tags", [None] * 4)][:4] + [None] * 4,
                        why=r.get("why", ""), ai=True)
    except Exception:
        pass
    pool = [q for q in BANK if q["c"] == c and q["id"] not in s.asked] or [q for q in BANK if q["c"] == c]
    return min(pool, key=lambda q: abs(q["d"] - d))

# ---------- 5. MISCONCEPTION DETECTION FROM REASONING ----------
def diagnose(q, choice, why):
    correct = choice == q["ans"]
    r = ai_json(f"""A student answered a physics MCQ and explained their reasoning.
Find any misconception shown in the REASONING, not just the option, even if the answer is correct.
Question: {q['q']}
Options: {q['opts']}
Correct: {q['opts'][q['ans']]}
Chosen: {q['opts'][choice]}
Reasoning: {why or '(none given)'}
Known misconceptions: {json.dumps(MISC)}
Rules: use only these ids. NONE if the reasoning is sound. UNCLEAR if too short to judge. Never invent labels.
Return JSON: {{"misconception": "M1..M6 or NONE or UNCLEAR", "evidence": "what in the reasoning shows it", "hint": "one Socratic hint that does not reveal the answer"}}""")
    if isinstance(r, dict) and r.get("misconception") in list(MISC) + ["NONE", "UNCLEAR"]:
        return r
    tag = None if correct else q["tags"][choice]
    return {"misconception": tag or "NONE", "evidence": "Inferred from the chosen option (AI offline)",
            "hint": "Re-read the question. What stays the same and what changes in the circuit?"}

def submit(choice, why):
    q = s.q; c = q["c"]; ok = choice == q["ans"]
    if s.attempt == 0:
        dx = diagnose(q, choice, why); mid = dx["misconception"] if dx["misconception"] in MISC else None
        old = s.m[c]; new = bkt(old, ok)
        if ok and mid: new = old + (new - old) * 0.3           # right answer, flawed reasoning
        s.m[c] = new
        a, t = s.stats.get(q["id"], (0, 0)); s.stats[q["id"]] = (a + ok, t + 1)
        s.streak[c] = s.streak[c] + 1 if ok and not mid else 0
        s.due[c] = s.day + INTERVALS[min(s.streak[c], len(INTERVALS) - 1)]
        if mid: s.misc[mid] += 1; s.focus[c] = mid
        elif ok: s.focus.pop(c, None)
        s.log.append(dict(c=c, ok=ok, mid=mid)); s.dx = dx; s.asked.add(q["id"])
    s.res = "done" if (ok or s.attempt >= 1) else "retry"
    s.attempt += 1

def advance():
    if s.phase == "diag":
        s.i += 1
        if s.i >= len(DIAG): s.phase = "adapt"
    s.q = None; s.res = None; s.attempt = 0; s.dx = None

# ---------- sidebar ----------
with st.sidebar:
    st.title("⚡ ConceptPilot")
    st.caption("Class 10 Physics · Electricity")
    st.subheader("Your mastery")
    for c, (lab, _) in CONCEPTS.items():
        m = s.m[c]; wait = s.due[c] - s.day
        st.progress(min(max(m, 0.0), 1.0), text=f"{lab}: {int(m * 100)}%")
        st.caption("Review now" if wait <= 0 else f"Next review in {wait} day(s)")
    if st.button("⏩ Fast-forward 3 days (demo spaced repetition)"):
        s.day += 3; s.q = None if s.res is None else s.q; st.rerun()
    if st.button("Reset session"):
        s.clear(); st.rerun()
    if s.ai_err: st.warning(f"AI offline, using built-in questions. ({s.ai_err})")
    else: st.success("AI connected")

tab1, tab2, tab3 = st.tabs(["🎓 Student", "📊 Teacher dashboard", "🧠 How it works"])

# ---------- STUDENT ----------
with tab1:
    if s.q is None:
        s.q = DIAG[s.i] if s.phase == "diag" else gen_q(pick_concept())
    q = s.q; c = q["c"]
    if s.phase == "diag":
        st.subheader(f"Diagnostic test · question {s.i + 1} of {len(DIAG)}")
    else:
        st.subheader(f"Adaptive practice · {CONCEPTS[c][0]}")
        st.caption(f"Chosen because mastery is {int(s.m[c] * 100)}% · difficulty level {q['d']} of 3"
                   + (" · AI-generated" if q.get("ai") else " · question bank")
                   + (f" · aimed at: {MISC[s.focus[c]]}" if s.focus.get(c) else ""))
    st.markdown(f"<div class='card'><b>{q['q']}</b></div>", unsafe_allow_html=True)
    k = f"{q['id']}_{len(s.log)}_{s.attempt}"
    if s.res in (None, "retry"):
        if s.res == "retry":
            st.info(f"💡 Hint: {s.dx['hint']}  Try once more.")
        with st.form(k):
            ch = st.radio("Choose one", range(4), format_func=lambda i: q["opts"][i], index=None)
            why = st.text_area("Why did you choose this? (one line)", height=70) if s.attempt == 0 else ""
            if st.form_submit_button("Submit answer") and ch is not None:
                submit(ch, why); st.rerun()
    else:
        st.success(f"Correct answer: {q['opts'][q['ans']]}")
        if q.get("why"): st.caption(q["why"])
        dx = s.dx; mid = dx["misconception"]
        label = MISC.get(mid, "No misconception found" if mid == "NONE" else "Reasoning too short to judge")
        st.markdown(f"<div class='card'>🧠 <b>AI diagnosis of your reasoning</b><br>{label}<br>"
                    f"<i>{dx['evidence']}</i></div>", unsafe_allow_html=True)
        if st.button("Next question"):
            advance(); st.rerun()
    with st.expander("Concept graph (colour = mastery)"):
        dot = "digraph{rankdir=LR;node[style=filled,shape=box,fontcolor=white,fontname=Helvetica];"
        for cid, (lab, pre) in CONCEPTS.items():
            m = s.m[cid]
            dot += f'{cid}[label="{lab}\\n{int(m * 100)}%",fillcolor="#{int(210 * (1 - m)):02x}{int(150 * m + 40):02x}50"];'
            dot += "".join(f"{p}->{cid};" for p in pre)
        st.graphviz_chart(dot + "}")

# ---------- TEACHER ----------
with tab2:
    st.subheader("Class-wide gaps")
    st.caption("⚠️ 20 students are SIMULATED for this demo. The 21st row is the live student from the Student tab.")
    rng = random.Random(7)
    means = dict(charge=.8, current=.55, pd=.42, ohm=.6, resistance=.62, series=.58, parallel=.4, power=.55)
    rows = [{"Student": f"S{i + 1:02d}", **{c: min(.98, max(.05, rng.gauss(means[c], .17))) for c in CONCEPTS}} for i in range(20)]
    rows.append({"Student": "You (live)", **s.m})
    df = pd.DataFrame(rows)
    avg = df[list(CONCEPTS)].mean().rename(index={c: CONCEPTS[c][0] for c in CONCEPTS})
    st.bar_chart(avg)
    risk = (df[list(CONCEPTS)] < 0.5).sum().rename(index={c: CONCEPTS[c][0] for c in CONCEPTS})
    st.write("**Students below 50% mastery, by concept**")
    st.dataframe(risk.rename("Students at risk").to_frame().T, use_container_width=True)
    base = dict(M1=11, M2=7, M3=9, M4=3, M5=6, M6=4)
    mc = pd.DataFrame({"Misconception": [MISC[k] for k in MISC], "Students": [base[k] + s.misc[k] for k in MISC],
                       "Suggested action": [ACTIONS[k] for k in MISC]}).sort_values("Students", ascending=False)
    st.write("**Most common misconceptions (detected from students' reasoning)**")
    st.dataframe(mc, use_container_width=True, hide_index=True)
    st.write("**Student heatmap**")
    st.dataframe(df, use_container_width=True, hide_index=True,
                 column_config={c: st.column_config.ProgressColumn(CONCEPTS[c][0], min_value=0, max_value=1) for c in CONCEPTS})
    with st.expander("Question difficulty calibration (updates from real answers)"):
        st.dataframe(pd.DataFrame([{"Question": q["id"], "Concept": CONCEPTS[q["c"]][0], "Labelled difficulty": q["d"] / 3,
                                    "Calibrated difficulty": emp_diff(q), "Answers seen": s.stats.get(q["id"], (0, 0))[1]}
                                   for q in BANK]), hide_index=True)

# ---------- HOW IT WORKS ----------
with tab3:
    st.markdown("""
**Where AI is used**
1. **Question generation:** an LLM writes a new question for the weakest concept, at the right difficulty, designed to expose the student's current misconception.
2. **Misconception detection:** an LLM reads the student's *reasoning* (even when the answer is right) and picks from a research-based list. It cannot invent labels.
3. **Socratic hints:** one hint, not the answer, then one retry.

**The seven parts**
- Diagnostic test: 8 questions, one per concept.
- Concept graph: prerequisites steer practice to weak foundations first.
- Learner model: Bayesian Knowledge Tracing updates mastery after every answer.
- Targeted questions: weakest or due concept, difficulty set by mastery, calibrated from real answers.
- Misconception detection: from reasoning text, with a "none/unclear" option.
- Spaced repetition: intervals of 1, 3, 7, 14 and 30 days; a wrong answer resets the ladder.
- Teacher dashboard: class gaps, misconception counts and suggested reteach actions.

**Honest limits:** class data is simulated. AI-generated questions need teacher review. Misconceptions come from published physics-education research. This is a prototype, not a validated assessment.
""")
